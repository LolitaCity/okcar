<?php

return [
    'authList' => [
        // 汽车管理
        'car' => 1,
        // 认证管理
        'auth' => 2,
        // 常见问题
        'qa' => 3,
        // 投诉建议
        'advice' => 4,
        // 客服
        'chat' => 5,
        // 权限管理
        'account' => 6,
        // 订单管理
        'order' => 7,
        // 金融方案管理
        'paymode' => 8
    ]
];
