<?php
/**
 * Created by IntelliJ IDEA.
 * User: lilina
 * Date: 2018/10/13
 * Time: 15:12
 */

namespace App\Models;


class PayMode extends BaseModel
{

    public $table = 'pay_mode';
}
