<?php

namespace App\Exceptions;

use \Exception;

/**
 * Created by IntelliJ IDEA.
 * User: lilina
 * Date: 2018/8/11
 * Time: 15:37
 */
class AppException extends Exception
{
}
